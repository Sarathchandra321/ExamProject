<div class="footer">
	<div class="container">
		<b class="copyright">&copy; {{ date('Y') }} - Automated Library Management System </b> All rights reserved.
	</div>
</div>
